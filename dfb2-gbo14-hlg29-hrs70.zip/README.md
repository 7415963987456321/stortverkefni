﻿# Stórt verkefni 1
## Vefforritun - TÖL107G - Október 2017

## Verkefni unnið af:

| Nafn   |      Email  |  Slack | Github|
|----------|:-------------:|------:|------|
| Davíð Freyr Björnsson |  dfb2@hi.is | dfb2 | [dfb2](http://github.com/dfb)|
| Guðmundur Ólafsson    | gbo14@hi.is |    gbo14 |[i-understand](http://github.com/i-understand)|
| Helga Lára            | hlg29@hi.is |    hlg29 |[hlg29](http://github.com/hlg29)|
| Hrafnkell Sigurðarson | hrs70@hi.is |    hrs70 |[7415963987456321](http://github.com/7415963987456321)|

## Upplýsingar um keyrslu vefsíðu

1. Til þess að keyra vefsíðuna þarf npm pakka til að keyra skipanir. Hann er settur upp með node.js sem hægt er að ná í á vefsíðunni https://nodejs.org/en/ 
2. Keyrum í Command Promt
3. Opna möppu sem inniheldur verkefni
4. Keyrum eftirfarandi skipanir

    `npm install`
    
    `npm run dev`
    
    `npm run lint -s`

## Uppsetning verkefnis
### HTML
Forsíða fyrir Fooþjónustuna

* index.html

Undirsíða með upplýsingum um Fooþjónustuna

* um.html

Undirsíða til þess að kaupa þjónustu Fooþjónustunnar

* kaupa.html

### CSS
Útlit síðunnar er í Styles.css
### SCSS
Alla SCSS pakka má finna í möppunni SCSS
### Myndir
Allar myndir sem eru notaðar í verkefninu eru í möppunni Gögn


    

